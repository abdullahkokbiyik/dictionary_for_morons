# improve your language skills

  Improve your language skills.
  You create can own dictionary with two languages.

## Prerequisites

It is coded and interpreted with python 3.5.2.
Also it require python 3x tkinter package.

### Usage

  1.Download source code.
  2.Reach the folder that it was downloaded in terminal.
  3.depend on your os, run with python 3x on terminal.

